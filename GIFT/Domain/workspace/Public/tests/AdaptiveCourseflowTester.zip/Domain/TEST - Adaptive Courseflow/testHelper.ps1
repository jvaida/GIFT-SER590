# Gets the course.xml files
$courseFiles = Get-ChildItem -Filter "*.course.xml";

# Extract the XML structure from the course.xml file and save a reference to the list of transitions
$xml = [xml] (Get-Content $courseFiles[0])
$transitions = (Select-Xml -Xml $xml -XPath "/Course/transitions/*" | Select-Object -ExpandProperty Node);

# Disable the first transition, introduction transition
$transitions[0].disabled = "true";

# Enable each of the 3-object-tests
$i = 0;
while(3 * $i + 3 -lt $transitions.Length) {
    # Get the three  that belong to the test
    $firstNode  = $transitions[3 * $i + 1];
    $secondNode = $transitions[3 * $i + 2];
    $thirdNode = $transitions[3 * $i + 3];

    # Enable each of the course objects for this test and save the new XML
    $firstNode.disabled = "false";
    $secondNode.disabled = "false";
    $thirdNode.disabled = "false";
    $xml.Save($courseFiles[0].FullName);

    # Inform the user that the new test is enabled and wait for user input to advance to the next test
    $testNum = $i + 1;
    Write-Host "Enabled Test $testNum";
    $key = [System.Console]::ReadKey();
    
    # Disable each of the course objects that were part of the test and save the updated XML again
    $firstNode.disabled = "true";
    $secondNode.disabled = "true";
    $thirdNode.disabled = "true";
    $xml.Save($courseFiles[0].FullName);

    # Increment the counter for the next test
    $i++;
}

# Enable the introduction transition again
$transitions[0].disabled = "false";

# Inform the user that the testing is complete
Write-Host "Testing completed";
$key = [System.Console]::ReadKey();