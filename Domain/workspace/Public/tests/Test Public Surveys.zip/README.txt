This is an export of GIFT Domain content selected from a GIFT instance using the GIFT export tool.  
It contains one or more exported courses (listed at the bottom of this README) that should be imported
into an existing full GIFT installation.

Quick Start

To import this domain content into an existing GIFT installation, you will need to run the Import tool.
Execute the "importDomains.bat" file located in GIFT/scripts/tools of a full GIFT installation.
You will notice the Import tool dialog appear on your computer.  Follow the prompts to import the domains.

GIFT Resources

For more information on GIFT or to collaborate with the GIFT
community, visit gifttutoring.org

Exported Domain Content 

C:\work\branches\gameMaster_3958\Domain\workspace\cpadilla\Test Public Surveys\
